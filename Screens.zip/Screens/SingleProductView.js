import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const SingleProductView = ({ navigation }) => {
  const [quantity, setQuantity] = useState(3);

  return (
    <SafeAreaView style={styles.container}>
      {/* Header / Background Shape */}
      <View style={styles.headerBackground}>
        <View style={styles.curvedShape} />
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => navigation?.goBack()}
        >
          <Ionicons name="arrow-back" size={28} color="black" />
        </TouchableOpacity>
        
        <Image
          source={{ uri: 'https://pngimg.com/uploads/lime/lime_PNG52.png' }} // Replace with local lime image
          style={styles.productImage}
        />
      </View>

      <ScrollView contentContainerStyle={styles.detailsContainer}>
        {/* Price and Wishlist */}
        <View style={styles.rowBetween}>
          <Text style={styles.price}>$2.22</Text>
          <TouchableOpacity>
            <Ionicons name="heart-outline" size={28} color="#999" />
          </TouchableOpacity>
        </View>

        {/* Title and Weight */}
        <Text style={styles.title}>Organic Lemons</Text>

        {/* Rating */}
        <View style={styles.ratingRow}>
          <Text style={styles.ratingText}>4.5</Text>
          {[1, 2, 3, 4].map((i) => (
            <Ionicons key={i} name="star" size={18} color="#FFC107" />
          ))}
          <Ionicons name="star-half" size={18} color="#FFC107" />
          <Text style={styles.reviewCount}>(89 reviews)</Text>
        </View>

        {/* Description */}
        <Text style={styles.description}>
          Organic Mountain works as a seller for many organic growers of organic
          lemons. Organic lemons are easy to spot in your produce aisle. They are
          just like regular lemons, but they will usually have a few more scars
          on the outside... <Text style={styles.moreText}>more</Text>
        </Text>

        {/* Quantity Selector */}
        <View style={styles.quantityContainer}>
          <Text style={styles.quantityLabel}>Quantity</Text>
          <View style={styles.stepper}>
            <TouchableOpacity 
              onPress={() => quantity > 1 && setQuantity(quantity - 1)}
              style={styles.stepButton}
            >
              <Ionicons name="remove" size={20} color="#67C100" />
            </TouchableOpacity>
            
            <View style={styles.quantityValueBox}>
              <Text style={styles.quantityValue}>{quantity}</Text>
            </View>

            <TouchableOpacity 
              onPress={() => setQuantity(quantity + 1)}
              style={styles.stepButton}
            >
              <Ionicons name="add" size={20} color="#67C100" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Add to Cart Button */}
        <TouchableOpacity style={styles.addToCartBtn}>
          <Text style={styles.addToCartText}>Add to cart</Text>
          <Ionicons name="bag-handle-outline" size={24} color="white" />
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FB',
  },
  headerBackground: {
    height: 350,
    alignItems: 'center',
    justifyContent: 'center',
  },
  curvedShape: {
    position: 'absolute',
    top: -100,
    width: '150%',
    height: 400,
    backgroundColor: '#EFFFDF', // Light lime background
    borderBottomLeftRadius: 300,
    borderBottomRightRadius: 300,
  },
  backButton: {
    position: 'absolute',
    top: 20,
    left: 20,
    zIndex: 10,
  },
  productImage: {
    width: 280,
    height: 280,
    resizeMode: 'contain',
    marginTop: 40,
  },
  detailsContainer: {
    paddingHorizontal: 25,
    marginTop:50
  },
  rowBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  price: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#67C100',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#000',
    marginTop: 5,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 15,
  },
  ratingText: {
    fontSize: 16,
    fontWeight: 'bold',
    marginRight: 5,
  },
  reviewCount: {
    color: '#999',
    marginLeft: 5,
  },
  description: {
    fontSize: 15,
    color: '#777',
    lineHeight: 22,
    marginTop: 20,
  },
  moreText: {
    fontWeight: 'bold',
    color: '#000',
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 10,
    marginTop: 30,
    borderWidth: 1,
    borderColor: '#eee',
  },
  quantityLabel: {
    fontSize: 16,
    color: '#999',
    marginLeft: 10,
  },
  stepper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  stepButton: {
    padding: 10,
  },
  quantityValueBox: {
    paddingHorizontal: 20,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: '#eee',
  },
  quantityValue: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  addToCartBtn: {
    backgroundColor: '#8BC34A',
    flexDirection: 'row',
    height: 60,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  addToCartText: {
    color: 'white',
    fontSize: 18,
    fontWeight: '600',
    marginRight: 10,
  },
});

export default SingleProductView;