import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native'
import React from 'react'
import { StatusBar } from 'expo-status-bar'
import { LinearGradient } from 'expo-linear-gradient' 

const SplashScreen = ({navigation}) => {
  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <Image 
          source={require("../assets/CoverImg.png")} 
          style={styles.image}
          resizeMode="cover"
        />
      </View>

      <View style={styles.footerContainer}>
        {/* Title Text */}
        <Text style={styles.title}>Get Discounts{"\n"}On All Products</Text>

        {/* Description Text */}
        <Text style={styles.description}>
          Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy
        </Text>

        {/* Gradient Button */}
        <TouchableOpacity style={styles.buttonWrapper} activeOpacity={0.8} onPress={()=>navigation.navigate("SignIn")}>
          <LinearGradient
            colors={['#A8E063', '#56AB2F']} // Adjusted to match the green gradient
            style={styles.button}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
          >
            <Text style={styles.buttonText}>Get started</Text>
          </LinearGradient>
        </TouchableOpacity>
      </View>

      <StatusBar style='auto'/>
    </View>
  )
}

const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor: '#ffffffff'
    },
    headerContainer:{
        width:"100%",
        height:"60%",
        backgroundColor:"#eee" 
    },
    image: {
        width: '100%',
        height: '100%',
    },
    footerContainer:{
        width:"100%",
        height:"40%",
        backgroundColor:"white",
        justifyContent:"center",
        alignItems:"center",
        borderTopEndRadius:30,
        borderTopStartRadius:30,
        paddingHorizontal: 30, 
        marginTop: -30, 
    },
    title: {
        fontSize: 28,
        fontWeight: 'bold',
        textAlign: 'center',
        color: '#000',
        marginBottom: 15,
    },
    description: {
        fontSize: 14,
        textAlign: 'center',
        color: '#888',
        marginBottom: 30,
        lineHeight: 20,
    },
    buttonWrapper: {
        width: '100%',
        borderRadius: 10,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.2,
        shadowRadius: 5,
        elevation: 5,
    },
    button: {
        paddingVertical: 15,
        borderRadius: 10,
        alignItems: 'center',
        justifyContent: 'center',
    },
    buttonText: {
        color: '#fff',
        fontSize: 18,
        fontWeight: '600',
    },
})

export default SplashScreen