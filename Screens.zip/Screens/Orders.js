import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

// Only 3 statuses used here
const ORDER_DATA = [
  { id: 'ORD-9910', date: 'Jan 02, 2026', price: '$24.50', status: 'Pending' },
  { id: 'ORD-8821', date: 'Jan 01, 2026', price: '$12.00', status: 'Off to delivery' },
  { id: 'ORD-7712', date: 'Dec 28, 2025', price: '$45.80', status: 'Delivered' },
  { id: 'ORD-6605', date: 'Dec 25, 2025', price: '$15.00', status: 'Off to delivery' },
];

const Orders = ({ navigation }) => {

  const getStatusStyle = (status) => {
    switch (status) {
      case 'Pending': return { color: '#FF9800', bg: '#FFF3E0' }; 
      case 'Off to delivery': return { color: '#2196F3', bg: '#E3F2FD' };
      case 'Delivered': return { color: '#67C100', bg: '#F1F8E9' }; 
      default: return { color: '#999', bg: '#F5F5F5' };
    }
  };

  const renderOrder = ({ item }) => {
    const styles_status = getStatusStyle(item.status);
    
    // Logic: Buttons only show for "Off to delivery"
    const isActiveDelivery = item.status === 'Off to delivery';

    return (
      <View style={styles.orderCard}>
        <View style={styles.cardHeader}>
          <View>
            <Text style={styles.orderNumber}>Order {item.id}</Text>
            <Text style={styles.orderDate}>{item.date}</Text>
          </View>
          <View style={[styles.statusBadge, { backgroundColor: styles_status.bg }]}>
            <Text style={[styles.statusText, { color: styles_status.color }]}>
              {item.status}
            </Text>
          </View>
        </View>

        <View style={styles.divider} />

        <View style={styles.cardFooter}>
          <View>
            <Text style={styles.priceLabel}>Total Price</Text>
            <Text style={styles.priceValue}>{item.price}</Text>
          </View>

          {isActiveDelivery ? (
            <View style={styles.buttonGroup}>
              <TouchableOpacity style={styles.receiveBtn}>
                <Ionicons name="checkmark-circle" size={16} color="white" />
                <Text style={styles.btnText}>Received</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <TouchableOpacity style={styles.detailsBtn}>
               <Text style={styles.detailsBtnText}>View Details</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation?.goBack()}>
          <Ionicons name="arrow-back" size={26} color="black" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Order History</Text>
        <View style={{ width: 26 }} />
      </View>

      <FlatList
        data={ORDER_DATA}
        keyExtractor={(item) => item.id}
        renderItem={renderOrder}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffffff',
    paddingTop: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#ffffffff',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  listContent: {
    padding: 20,
  },
  orderCard: {
    backgroundColor: '#fff',
    borderRadius: 18,
    padding: 20,
    marginBottom: 15,
    elevation: 3,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 10,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  orderNumber: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1A1A1A',
  },
  orderDate: {
    fontSize: 13,
    color: '#999',
    marginTop: 2,
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
  },
  statusText: {
    fontWeight: '700',
    fontSize: 12,
  },
  divider: {
    height: 1,
    backgroundColor: '#F5F5F5',
    marginVertical: 15,
  },
  cardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  priceLabel: {
    fontSize: 12,
    color: '#999',
  },
  priceValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  buttonGroup: {
    flexDirection: 'row',
    gap: 8,
  },
  trackBtn: {
    backgroundColor: '#2196F3',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    gap: 4,
  },
  receiveBtn: {
    backgroundColor: '#67C100',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    gap: 4,
  },
  btnText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 12,
  },
  detailsBtn: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: '#F5F6F8',
  },
  detailsBtnText: {
    color: '#555',
    fontWeight: '600',
    fontSize: 12,
  }
});

export default Orders;