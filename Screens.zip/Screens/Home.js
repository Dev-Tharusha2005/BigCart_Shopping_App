import React from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  Dimensions,
} from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';

const { width } = Dimensions.get('window');

// Category Data
const CATEGORIES = [
  { id: '1', icon: 'leaf', color: '#4CAF50', bgColor: '#E8F5E9' },
  { id: '2', icon: 'apple', color: '#FF5252', bgColor: '#FFEBEE' },
  { id: '3', icon: 'cup-water', color: '#FFB300', bgColor: '#FFF8E1' },
  { id: '4', icon: 'basket', color: '#9C27B0', bgColor: '#F3E5F5' },
  { id: '5', icon: 'bottle-tonic-plus', color: '#00BCD4', bgColor: '#E0F7FA' },
];

// Product Data - Matching your style
const PRODUCTS = [
  { 
    id: '1', 
    name: 'Fresh Peach', 
    price: '$8.00', 
    image: 'https://cdn-icons-png.flaticon.com/512/2909/2909893.png', // Replace with your local require()
    bgColor: '#FFD1C1' 
  },
  { 
    id: '2', 
    name: 'Avocado', 
    price: '$6.50', 
    image: 'https://cdn-icons-png.flaticon.com/512/2909/2909808.png', 
    bgColor: '#D7F1E1' 
  },
  { 
    id: '3', 
    name: 'Pineapple', 
    price: '$5.00', 
    image: 'https://cdn-icons-png.flaticon.com/512/2909/2909761.png', 
    bgColor: '#FFF4CF' 
  },
  { 
    id: '4', 
    name: 'Grapes', 
    price: '$12.00', 
    image: 'https://cdn-icons-png.flaticon.com/512/2909/2909841.png', 
    bgColor: '#E8DFF5' 
  },
];

const Home = ({navigation}) => {

  const renderHeader = () => (
    <View>
      {/* Top Bar */}
      <View style={styles.topBar}>
        <Image
          source={require('../assets/logo.png')} 
          style={styles.logo}
        />
        <TouchableOpacity onPress={()=>navigation.navigate("UserProfile")}>
          <Ionicons name="person-circle-outline" size={36} color="#333" />
        </TouchableOpacity>
      </View>

      {/* Search Section */}
      <View style={styles.searchSection}>
        <Ionicons name="search-outline" size={20} color="#8e8e8e" style={styles.searchIcon} />
        <TextInput
          style={styles.input}
          placeholder="Search keywords.."
          placeholderTextColor="#8e8e8e"
        />
      </View>

      {/* Categories Section */}
      <View style={styles.categoryContainer}>
        <Text style={styles.headerText}>Categories</Text>
        <FlatList
          data={CATEGORIES}
          horizontal
          showsHorizontalScrollIndicator={false}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <TouchableOpacity style={[styles.iconCircle, { backgroundColor: item.bgColor }]}>
              <MaterialCommunityIcons name={item.icon} size={30} color={item.color} />
            </TouchableOpacity>
          )}
        />
      </View>

      <Text style={[styles.headerText, { marginTop: 10 }]}>Popular Products</Text>
    </View>
  );

  const renderProduct = ({ item }) => (
    <View style={styles.productCard}>
      {/* Heart Icon */}
      <TouchableOpacity style={styles.wishlistBtn}>
        <Ionicons name="heart-outline" size={22} color="#999" />
      </TouchableOpacity>

      {/* Image with background circle */}
      <View style={styles.imageContainer}>
        <View style={[styles.bgCircle, { backgroundColor: item.bgColor }]} />
        <Image source={{ uri: item.image }} style={styles.productImage} />
      </View>

      {/* Text Info */}
      <View style={styles.infoContainer}>
        <Text style={styles.priceText}>{item.price}</Text>
        <Text style={styles.productName}>{item.name}</Text>
      </View>

      {/* Add to Cart Button */}
      <TouchableOpacity style={styles.addToCartBtn} onPress={()=>navigation.navigate("SingleProductView")}>
        <Ionicons name="bag-outline" size={18} color="#67C100" />
        <Text style={styles.addToCartText}>Add to cart</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.mainWrapper}>
      <FlatList
        data={PRODUCTS}
        keyExtractor={(item) => item.id}
        renderItem={renderProduct}
        numColumns={2}
        columnWrapperStyle={styles.row}
        ListHeaderComponent={renderHeader}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollPadding}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  mainWrapper: {
    flex: 1,
    backgroundColor: '#fff',
    paddingTop: 40,
  },
  scrollPadding: {
    paddingHorizontal: 20,
    paddingBottom: 30,
  },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  logo: {
    width: 150,
    height: 40,
    resizeMode: 'contain',
  },
  searchSection: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f5f6f8',
    borderRadius: 12,
    paddingHorizontal: 15,
    height: 50,
    marginBottom: 30,
  },
  searchIcon: {
    marginRight: 10,
  },
  input: {
    flex: 1,
    fontSize: 16,
  },
  categoryContainer: {
    marginBottom: 20,
  },
  headerText: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#000',
  },
  iconCircle: {
    width: 65,
    height: 65,
    borderRadius: 35,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },

  /* Product Grid Styles */
  row: {
    justifyContent: 'space-between',
  },
  productCard: {
    backgroundColor: '#fff',
    width: (width - 55) / 2, // Dynamic width for 2 columns
    borderRadius: 15,
    borderWidth: 1,
    borderColor: '#f0f0f0',
    marginBottom: 15,
    overflow: 'hidden',
    alignItems: 'center',
  },
  wishlistBtn: {
    position: 'absolute',
    top: 10,
    right: 10,
    zIndex: 1,
  },
  imageContainer: {
    height: 120,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 15,
  },
  bgCircle: {
    position: 'absolute',
    width: 90,
    height: 90,
    borderRadius: 45,
  },
  productImage: {
    width: 80,
    height: 80,
    resizeMode: 'contain',
  },
  infoContainer: {
    paddingVertical: 10,
    alignItems: 'center',
  },
  priceText: {
    color: '#67C100',
    fontSize: 16,
    fontWeight: 'bold',
  },
  productName: {
    fontSize: 18,
    fontWeight: '800',
    color: '#000',
  },
  addToCartBtn: {
    flexDirection: 'row',
    width: '100%',
    paddingVertical: 12,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  addToCartText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#000',
  },
});

export default Home;