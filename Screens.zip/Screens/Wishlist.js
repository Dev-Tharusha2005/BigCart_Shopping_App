import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Image,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

// Sample Wishlist Data matching your product style
const INITIAL_WISHLIST = [
  { id: '1', name: 'Fresh Peach', price: '$8.00', image: 'https://cdn-icons-png.flaticon.com/512/2909/2909893.png', bgColor: '#FFD1C1' },
  { id: '2', name: 'Organic Lemons', price: '$2.22', image: 'https://pngimg.com/uploads/lime/lime_PNG52.png', bgColor: '#EFFFDF' },
  { id: '3', name: 'Avocado', price: '$6.50', image: 'https://cdn-icons-png.flaticon.com/512/2909/2909808.png', bgColor: '#D7F1E1' },
];

const Wishlist = ({ navigation }) => {
  const [wishlistItems, setWishlistItems] = useState(INITIAL_WISHLIST);

  const removeItem = (id) => {
    setWishlistItems(prev => prev.filter(item => item.id !== id));
  };

  const renderItem = ({ item }) => (
    <View style={styles.wishlistCard}>
      {/* Product Image with Signature Circle Background */}
      <View style={[styles.imageContainer, { backgroundColor: item.bgColor }]}>
        <Image source={{ uri: item.image }} style={styles.productImage} />
      </View>

      <View style={styles.detailsContainer}>
        <View style={styles.titleRow}>
          <Text style={styles.itemName}>{item.name}</Text>
          <TouchableOpacity onPress={() => removeItem(item.id)}>
            <Ionicons name="heart" size={24} color="#FF5252" />
          </TouchableOpacity>
        </View>
        
        <Text style={styles.itemPrice}>{item.price}</Text>

        <TouchableOpacity style={styles.addToCartBtn}>
          <Ionicons name="bag-add-outline" size={18} color="white" />
          <Text style={styles.addToCartText}>Add to Cart</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation?.goBack()}>
          <Ionicons name="arrow-back" size={26} color="black" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>My Wishlist</Text>
        <View style={{ width: 26 }} />
      </View>

      <FlatList
        data={wishlistItems}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Ionicons name="heart-dislike-outline" size={80} color="#DDD" />
            <Text style={styles.emptyText}>Your wishlist is empty</Text>
          </View>
        }
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    paddingTop: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
  },
  listContent: {
    padding: 20,
  },
  wishlistCard: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 15,
    marginBottom: 20,
    alignItems: 'center',
    // Soft shadow
    elevation: 3,
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 10,
    borderWidth: 1,
    borderColor: '#F0F0F0',
  },
  imageContainer: {
    width: 90,
    height: 90,
    borderRadius: 45,
    justifyContent: 'center',
    alignItems: 'center',
  },
  productImage: {
    width: 70,
    height: 70,
    resizeMode: 'contain',
  },
  detailsContainer: {
    flex: 1,
    marginLeft: 20,
    justifyContent: 'center',
  },
  titleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  itemName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  itemPrice: {
    fontSize: 18,
    fontWeight: '700',
    color: '#67C100', // Matches your theme green
    marginTop: 4,
  },
  addToCartBtn: {
    backgroundColor: '#8BC34A',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    borderRadius: 10,
    marginTop: 12,
    width: '100%',
  },
  addToCartText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 14,
    marginLeft: 8,
  },
  emptyContainer: {
    alignItems: 'center',
    marginTop: 100,
  },
  emptyText: {
    fontSize: 18,
    color: '#999',
    marginTop: 15,
    fontWeight: '500',
  },
});

export default Wishlist;